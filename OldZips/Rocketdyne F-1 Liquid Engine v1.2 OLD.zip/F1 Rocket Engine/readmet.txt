﻿All contents including mesh, texture and config file created by 1096bimu

all permissions granted, do whatever you want with it.

Extract this folder to GameData